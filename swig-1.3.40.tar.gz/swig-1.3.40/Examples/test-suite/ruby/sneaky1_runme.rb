#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'sneaky1'

x = Sneaky1.add(3, 4)
y = Sneaky1.subtract(3, 4)
z = Sneaky1.mul(3, 4)
w = Sneaky1.divide(3, 4)
